﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Employee.Api.Infrastructure.Migrations
{
    public partial class ChangeNameToFullname : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Employee",
                newName: "Fullname");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Fullname",
                table: "Employee",
                newName: "Name");
        }
    }
}
