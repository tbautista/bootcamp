﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Employee.Api.Infrastructure.Migrations
{
    public partial class AdditionalTestData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Employee",
                columns: new[] { "EmployeeId", "Fullname" },
                values: new object[] { 3, "Abdel Hadji" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Employee",
                keyColumn: "EmployeeId",
                keyValue: 3);
        }
    }
}
