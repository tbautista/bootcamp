using Employee.Api.Models;
using Employee.Api.Infrastructure.EntityConfiguration;
using Microsoft.EntityFrameworkCore;

namespace Employee.Api.Infrastructure
{
    public class EmployeeContext : DbContext
    {
        public EmployeeContext(DbContextOptions<EmployeeContext> options) : base(options)
        {}
        public DbSet<EmployeeModel> Employees {get;set;}

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new EmployeeEntityConfiguration());
            EmployeeContextSeed.Seed(builder);
        }
    }
}