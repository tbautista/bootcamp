using Employee.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Employee.Api.Infrastructure.EntityConfiguration
{
    public class EmployeeEntityConfiguration : IEntityTypeConfiguration<EmployeeModel>
    {
        public void Configure(EntityTypeBuilder<EmployeeModel> builder)
        {
            builder.ToTable("Employee");

            builder.HasKey(x => x.EmployeeId);
            builder.Property(x => x.EmployeeId)
                .HasColumnName(@"EmployeeId")
                .HasColumnType("int")
                .IsRequired();
            
            builder.Property(x => x.Fullname)
                .HasColumnName(@"Fullname")
                .HasColumnType("varchar(100)")
                .HasMaxLength(100)
                .IsRequired();
            
        }
    }
}