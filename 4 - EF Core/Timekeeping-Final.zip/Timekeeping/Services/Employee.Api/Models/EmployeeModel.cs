namespace Employee.Api.Models
{
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }
        public string Fullname { get; set; }
    }
}
