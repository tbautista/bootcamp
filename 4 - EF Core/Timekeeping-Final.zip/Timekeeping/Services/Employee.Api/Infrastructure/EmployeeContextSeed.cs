using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Employee.Api.Models;

namespace Employee.Api.Infrastructure
{
    public class EmployeeContextSeed
    {
        public static void Seed(ModelBuilder builder)
        {
            List<EmployeeModel> employees = new List<EmployeeModel>();
            employees.Add(new EmployeeModel() {EmployeeId = 1, Fullname = "Mike Rondero"});
            employees.Add(new EmployeeModel() {EmployeeId =2, Fullname = "Rec Santos"});
            employees.Add(new EmployeeModel() {EmployeeId =3, Fullname = "Abdel Hadji"});
            builder.Entity<EmployeeModel>().HasData(employees);
        }
    }

}